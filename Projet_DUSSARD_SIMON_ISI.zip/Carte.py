# -*- coding: utf-8 -*-
"""
Auteurs : Bastien DUSSARD , Louis SIMON

Classe mère et classes filles gérant les cartes dans le jeu
Il existe quatre types de cartes (développées ici sous forme de classes filles):
	* Parade
	* Attaque
	* Borne
	* Botte
	
L'héritage permet ici de considérer une carte comme quelconques et par disjonction, identifier sa fonction	
"""

class Carte():
	
	def __init__(self,typeC):
		
		if typeC not in ['borne','attaque','parade','botte']:
			print("Type de carte inconnu")
			pass
		self.__typeCarte = typeC
		
	
	@property
	def typeCarte(self):
		return self.__typeCarte
	
	def __str__(self):
		return 'Carte de type '
		
	
###############################################################################	
	
class Parade(Carte):
	
	def __init__(self,typeP):
		
		super().__init__('parade')
		if typeP not in ['feuVert','finLimit','gas','roue','repair']:
			print("Type de carte parade inconnu")
			pass
		self.__typeParade = typeP
	
	@property
	def typeParade(self):
		return self.__typeParade
	
	def __str__(self):
		res = super().__str__()
		if self.__typeParade == 'feuVert' : res += 'parade : feu vert'
		if self.__typeParade == 'finLimit' : res += 'parade : fin de limitation de vitesse'
		if self.__typeParade == 'gas' : res += 'parade : essence'
		if self.__typeParade == 'roue' : res += 'parade : roue de secours'
		if self.__typeParade == 'repair' : res += 'parade : réparation'
		return res


###############################################################################

	
class Attaque(Carte):
	
	def __init__(self,typeA):
		
		super().__init__('attaque')
		if typeA not in ['feuRouge','debLimit','panne','crevaison','accident']:
			print("Type de carte attaque inconnu")
			pass
		self.__typeAttaque = typeA
		
	def __str__(self):
		res = super().__str__()
		if self.__typeAttaque == 'feuRouge' : res += 'attaque : feu rouge'
		if self.__typeAttaque == 'debLimit' : res += 'attaque : limitation de vitesse à 50 km'
		if self.__typeAttaque == 'panne' : res += "attaque : panne d'essence"
		if self.__typeAttaque == 'crevaison' : res += 'attaque : crevaison'
		if self.__typeAttaque == 'accident' : res += 'attaque : accident'
		return res
	
	@property
	def typeAttaque(self):
		return self.__typeAttaque


###############################################################################
		
		
class Borne(Carte):
	
	def __init__(self,value):
		super().__init__('borne')
		
		if value not in [25,50,75,100,200]:
			print("Type de carte borne inconnu")
			pass
		self.__valeur = value
	
	def __str__(self):
		res = super().__str__()
		res += 'borne : {} km'.format(self.__valeur)
		return res
		
	@property
	def valeur(self):
		return self.__valeur

###############################################################################

		
class Botte(Carte):
	
	def __init__(self,typeB):
		
		super().__init__('botte')
		if typeB not in ['prio','essence','increvable','drive']:
			print("Type de carte botte inconnu")
			pass
		self.__typeBotte = typeB
		
		
	def __str__(self):
		res = super().__str__()
		if self.__typeBotte == 'prio' : res += 'botte : véhicule prioritaire'
		if self.__typeBotte == 'essence' : res += "botte : citerne d'essence"
		if self.__typeBotte == 'increvable' : res += 'botte : increvable'
		if self.__typeBotte == 'drive' : res += 'botte : as du volant'
		return res
		
	@property
	def typeBotte(self):
		return self.__typeBotte