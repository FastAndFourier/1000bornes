# -*- coding: utf-8 -*-
"""
Created on Sun Jan 10 16:04:31 2021

@author: dussa
"""

import sys
import winsound
import tkinter as tk
from tkinter import * 
from PIL import Image, ImageTk
import os


from Joueur import Joueur
from Pile import Pile
from Carte import Carte
from Partie import Partie

class GUI():
    
    def __init__(self):
        self.nb_joueurs=[0]
        self.nb_manches=[0]
        self.score_manches=None
        self.players=[]
        self.liste_noms=[]
        self.sound=0
        self.manches=1
        self.partie=None
        self.joueur_actuel=0
        self.Spin_Joueurs=None
        self.Spin_Manches=None
        self.Check_sound=None
        self.var=None
        self.menu=None
        self.joueurs=None
        self.entree=None
        self.jeu=None
        self.gagnant=None
        self.Fin_de_Partie=None
        
    def load_nb_joueurs(self):
        self.nb_joueurs=(self.Spin_Joueurs.get())
        self.score_manches=[]*int(self.nb_joueurs)
        
    def load_nb_manches(self,):
        self.nb_manches=(self.Spin_Manches.get())
        
    def jouer(self):
        if len(self.nb_joueurs) != 0:
            self.menu.destroy()
            #a=[self.nb_joueurs[-1],self.nb_manches[-1]]
            self.window2()
            
    def window1(self):
        self.menu=tk.Tk() #fenêtre principale
        self.menu.geometry("500x500") 
        self.menu.title("1000 Bornes")
        
        winsound.PlaySound("background.wav", winsound.SND_ALIAS|winsound.SND_ASYNC)

        photo_menu = PhotoImage(master=self.menu, file='img_menu.ppm')
        canvas = Canvas(self.menu)
        canvas.create_image(200,200,image=photo_menu)
        canvas.pack()
       
        Frame_Joueur = Frame(self.menu)
        Frame_Joueur.pack()
        
        Label_joueur = tk.Label(Frame_Joueur, text="Nombre de joueurs : ")#créé un texte en bleu
        Label_joueur.pack()

        self.Spin_Joueurs = Spinbox(Frame_Joueur, from_=2, to=4)
        Btn_joueurs = Button(Frame_Joueur, text = 'Valider le nombre de joueurs', width = 30,command=self.load_nb_joueurs)
        self.Spin_Joueurs.pack()
        Btn_joueurs.pack() 
        
        Label_Manches = tk.Label(Frame_Joueur, text="Nombre de manches : ")
        Label_Manches.pack()

        self.Spin_Manches = Spinbox(Frame_Joueur,from_=1, to=4)
        Btn_manches = Button(Frame_Joueur, text = 'Valider le nombre de manches', width = 30,command=self.load_nb_manches)
        self.Spin_Manches.pack()
        Btn_manches.pack()
        
        Frame_Joueur2 = Frame(self.menu)
        Frame_Joueur2.pack()
 
        bouton2=tk.Button(Frame_Joueur2, text="Jouer",command=self.jouer) #lance la partie
        bouton2.pack()
        Btn_Quit=tk.Button(Frame_Joueur2, text="Fermer le jeu", command=self.menu.destroy)
        Btn_Quit.pack()
        
        self.menu.mainloop()
        
    def jouer2(self):
        self.joueurs.destroy()
        self.partie = Partie(self.players,self.sound)
        self.partie.creerDeck()
        self.partie.melangerDeck()
        self.partie.distribDeck()
        self.partie.demarrerPartie()
        winsound.PlaySound(None, winsound.SND_PURGE)
        self.window3()
        
    def recup_nom(self):
        entry_list=''
        i=0
        for entries in self.liste_noms:
            self.liste_noms[i]=str(entries.get())    #on sauvegarde les noms des joueurs
            self.players.append(Joueur(str(entries.get()),1))
            i+=1
        print(self.players)
    
    def window2(self):
    
        self.joueurs=tk.Tk()
        self.joueurs.title("Nom des Joueurs")
        self.joueurs.geometry("500x500")
        label3 = Frame(self.joueurs)
        label3.pack(side="top")
        
            
        for i in range(0, int(self.nb_joueurs)):
            txt="Joueur n°"+str(i+1)+" : "
            label = tk.Label(label3, text=txt)
            label.pack()
            
            self.entree = Entry(label3, width=30)#créé un case à remplir avec "texte par défaut"
            self.entree.pack()
            self.liste_noms.append(self.entree)  
            
        
        bouton = tk.Button(self.joueurs, text="Valider les nom",command=self.recup_nom)
        bouton.pack()
            
        bouton2 = tk.Button(self.joueurs, text="Lancer la partie",command=self.jouer2)
        bouton2.pack()
        Btn_Quit=tk.Button(label3, text="Fermer le jeu", command=self.joueurs.destroy) # quitte le jeu
        Btn_Quit.pack()
        
        self.joueurs.mainloop()
    
    def recup_choix_jouer(self):
        choice=1
        self.n_carte=self.Spin_jouer.get()
        self.n_joueur=self.Spin_jouer1.get()
        
        res_jeu=self.partie.jouerGUI(self.partie.joueur[self.joueur_actuel],choice,self.n_carte,self.partie.joueur[int(self.n_joueur)-1])
        if res_jeu[0]==0:      #si le joueur ne peut pas poser la carte, on affiche un message d'erreur
            Erreur=Toplevel()
            txt=str(res_jeu[1])
            Label_erreur=Label(Erreur,text=txt)
            Label_erreur.grid()
            Erreur.mainloop()
            
        if res_jeu[0]==2: #si le joueur a joué une botte, il peut rejouer
            Botte=Toplevel()
            txt=str(res_jeu[1])
            Label_botte=Label(Botte,text=txt)
            Label_botte.grid()
            Botte.mainloop()
            
        if self.partie.finPartie()==1:  #on teste si le joueur actuel a atteint 1000 km
            self.gagnant=self.partie.joueur[joueur_actuel].nom
            self.score_manches[int(self.joueur_actuel)]+=1
            self.jouer3()
        else:
            self.joueur_actuel+=1
            if self.joueur_actuel>=len(self.partie.joueur):
                self.joueur_actuel=0
            self.jeu.destroy() 
            self.window3()
        
    def defausser(self):
        choice=2
        self.n_carte=self.Spin_def.get()
        self.partie.jouerGUI(self.partie.joueur[self.joueur_actuel],choice,iCarte=self.n_carte,targetPl=None)
        self.joueur_actuel+=1
        if self.joueur_actuel>=len(self.partie.joueur):
            self.joueur_actuel=0
        self.jeu.destroy()
        self.window3()
        
            
    def pass_turn(self):
        choice=3

        self.partie.jouerGUI(self.partie.joueur[self.joueur_actuel],choice,iCarte=None,targetPl=None)
        self.joueur_actuel+=1
        if self.joueur_actuel>=len(self.partie.joueur):
            self.joueur_actuel=0
        self.jeu.destroy()
        self.window3()
    
        
            
    def jouer3(self):
        self.jeu.destroy()
        self.window4()
    
    def window3(self):
        self.jeu=tk.Tk()
        self.jeu['bg']='white'
        self.jeu.geometry("1000x1000")
        self.jeu.title("Manche n°"+str(self.manches)+"/"+str(self.nb_manches[-1]))

        
        frame1=LabelFrame(self.jeu,font=(None,15),text="Tour de jeu de : "+str(self.partie.joueur[self.joueur_actuel].nom), width=500, height=300, background="Blue")
        frame1.grid(row=0, column=0)
        frame1.grid_propagate(0)
        for i in range(1,7):
            cartes=Label(frame1,text=str(i)+"."+self.partie.joueur[self.joueur_actuel].getCarteMain(i-1).__str__())
            cartes.grid(row=i,column=0,sticky='nw')
            

        frame2=LabelFrame(self.jeu,font=(None,15),text="Actions : ", width=500, height=300, background="Red")
        frame2.grid(row=1, column=0,sticky='nw')
        frame2.grid_propagate(0)
        
        label_def=Label(frame2,text='Défausser')
        label_def.grid(row=0, column=0)
        self.Spin_def = Spinbox(frame2,from_=1, to=6)
        self.Spin_def.grid(row=0, column=1)
        btn_def=Button(frame2, text='OK',command=self.defausser)
        btn_def.grid(row=0, column=2)
        
        label_jouer=Label(frame2,text='Jouer')
        label_jouer.grid(row=1, column=0)
        self.Spin_jouer = Spinbox(frame2,from_=1, to=len(self.partie.joueur[self.joueur_actuel].main._element))
        self.Spin_jouer.grid(row=1, column=1)
        self.Spin_jouer1 = Spinbox(frame2,from_=1, to=len(self.partie.joueur))
        self.Spin_jouer1.grid(row=1, column=2)
        btn_jouer=Button(frame2, text='OK',command=self.recup_choix_jouer)
        btn_jouer.grid(row=1, column=3)
        
        
        
        label_pass=Label(frame2,text='Passer son tour')
        label_pass.grid(row=2, column=0)
        btn_pass=Button(frame2, text='OK',command=self.pass_turn)
        btn_pass.grid(row=2, column=1)
        

        frame3=LabelFrame(self.jeu,font=(None,15),text="Etats des Joueurs", width=500, height=300, background="Green")
        frame3.grid(row=0, column=1,sticky='nw')
        frame3.grid_propagate(0)
            
        for i in range(0,len(self.partie.joueur)):
            
            txt2=str(self.partie.joueur[i].printPlateauGUI())
            liste_etats = Label(frame3, text=txt2)
            liste_etats.grid(sticky='nw')
        
        
    
        frame4=LabelFrame(self.jeu,font=(None,15),text="Tableau des scores", width=500, height=300, background="Yellow")
        frame4.grid(row=1, column=1,sticky='nw')
        frame4.grid_propagate(0)
        
        for i in range(0,len(self.partie.joueur)):
            txt="Joueur n°"+str(i+1)+": "+str(self.partie.joueur[i].nom)+"  score :"+str(self.partie.joueur[i].score)
            score_j = Label(frame4, text=txt)
            score_j.grid()
        
    
        Btn_Quit=tk.Button(self.jeu, text="Fermer le jeu", command=self.jeu.destroy) # quitte le jeu
        Btn_Quit.grid(row=2, column=1)
    
        self.jeu.mainloop()    
        
        
        
    def jouer4(self):
        
        print(self.manches,self.nb_manches[-1])
        if int(self.manches)==int(self.nb_manches[-1]): # si on a fini le nb de manches, on passe à l'écran de fin
            self.Fin_de_Manche.destroy()
            self.window5()
        else:
            self.manches+=1                             #sinon on redémarre une partie avec les mêmes joueurs
            self.Fin_de_Manche.destroy()
            self.players.clear()              #on vide l'ancienne liste de joueurs
            self.partie=None     
            for i in range(0,len(self.liste_noms)):
                self.players.append(Joueur(str(self.liste_noms[i]),1)) #on remplit la liste de joueurs avec les noms des joueurs de la manche d'avant
            self.partie = Partie(self.players,self.sound)
            self.partie.creerDeck()
            self.partie.melangerDeck()
            self.partie.distribDeck()
            self.partie.demarrerPartie()
            self.window3()
        
    
    def window4(self):
        self.Fin_de_Manche=tk.Tk()
        self.Fin_de_Manche.geometry("600x400")
        
        Joueur_Gagnant=Frame(self.Fin_de_Manche)
        Joueur_Gagnant.pack()
        Label(Joueur_Gagnant, text="Manche Gagnée par : ").pack()
        Nom_Gagnant = tk.Label(Joueur_Gagnant, text=str(self.gagnant))
        Nom_Gagnant.pack()
        
        Score=Frame(self.Fin_de_Manche)
        Label(Score, text="Tableau des scores : ").pack()
        Score.pack(side=BOTTOM)
        Score_Joueurs=Frame(Score)
        Score_Joueurs.pack()
        
        for i in range(0, len(self.partie.joueur)):
            txt="Joueur n°"+str(i+1)+": "+str(self.partie.joueur[i].nom)+"  score :"+str(self.partie.joueur[i].score)
            score_des_joueurs = tk.Label(Score, text=txt)
            score_des_joueurs.pack()
            
        
        Btn_next_manche = Button(Score, text = 'Cliquer ici pour démarrer la manche suivante ou terminer la partie si les manches ont été jouées'+str(self.manches)+'/'+str(self.nb_manches[-1]),command=self.jouer4)
        Btn_next_manche.pack()
    
        Btn_Quit=tk.Button(Score, text="Fermer le jeu", command=self.Fin_de_Manche.destroy) # quitte le jeu
        Btn_Quit.pack(side=BOTTOM)
        self.Fin_de_Manche.mainloop()
        
    def window5(self):
        
        self.Fin_de_Partie=tk.Tk()
        self.Fin_de_Partie.geometry("400x400")
        
        Tableau_Final=Frame(self.Fin_de_Partie)
        Label(Tableau_Final, text="Tableau final des scores : ").pack()
        Tableau_Final.pack()
    
        for i in range(0, len(self.partie.joueur)):
            txt="Joueur n°"+str(i+1)+": "+str(self.partie.joueur[i].nom)+"  nombre de manches gagnées :"+str(self.score_manches[i])
            score_des_joueurs = tk.Label(Tableau_Final, text=txt)
            score_des_joueurs.pack()
        
        Gagnant=Frame(self.Fin_de_Partie)
        Gagnant.pack()
        
        photo_menu_win = PhotoImage(master=Gagnant, file="img_win2.ppm")
        canvas = Canvas(Gagnant)
        canvas.create_image(200,200,image=photo_menu_win)
        canvas.pack()
        
        Btn_Quit=tk.Button(self.Fin_de_Partie, text="Fermer le jeu", command=self.Fin_de_Partie.destroy) # quitte le jeu
        Btn_Quit.pack(side=BOTTOM)
     
        self.Fin_de_Partie.mainloop()
   
        
""" Exécuter GUI.py pour lancer l'interface graphique"""
G = GUI()
G.window1()



