# -*- coding: utf-8 -*-
"""
Auteurs : Bastien DUSSARD , Louis SIMON

Classe gérant les joueurs dans le jeu.
On y retrouve des fonctions de gestion de cartes ainsi que des fonctions vérifiant si il est possible de poser une carte
et dans le cas, permet de la poser.

Le joueur peut se retrouver dans l'un des quatre états suivants :
    
    # etat = -1 : le joueur n'a pas encore démarré la partie          
    # etat = 0 : le joueur est à l'arrêt suite à une attaque
    # etat = 1 : Le joueur est ralenti 
    # etat = 2 : le joueur roule
    
"""
from Pile import pBorne, pVitesse, pBataille, pBotte, pMain
from Carte import Parade


class Joueur():
    
    def __init__(self,name,s):
        
        self.nom = name
        self.__etat = -1         
        self.__plateau = [pBorne([0]*5),pVitesse(-1),
                          pBataille([-1,None]),pBotte([0,0,0,0])]
      
        self.__main = pMain([])
        self.score = 0
        self.sound = s
        
        
################### Getter et setter ##########################################        
    @property
    def etat(self):
        return self.__etat 
    
    @etat.setter
    def etat(self,e):
        self.__etat = e
                
    @property
    def main(self):
        return self.__main 
                             
################# Fonctions d'affichage #######################################        
           
    def printMain(self):
        """
        --> Affiche la main du joueur        
        Entrée :  -    
        Sortie :  -               
        """
        print('Main de',self.nom,':')
        print(self.__main)
    
    
    
    def printPlateau(self):
        print('Plateau de ',self.nom,'(',end=' ') 
        print(self.score,'km ,',end=' ')   
        if self.etat == -1:
            print('stationné',end='')
        elif self.etat == 0:
            print('arrêté , ',self.__plateau[2]._element[1],end='')
        elif self.etat == 1:
            print('ralenti',end='')
        else :
            print('roule à toute allure',end='')
        print(',',self.__plateau[-1],end=') \n')  
            
            
    def printPlateauGUI(self):
        res = 'Plateau de ' + self.nom + ' ( ' + str(self.score) + ' km , '         
        if self.etat == -1:
            res += 'stationné'
        elif self.etat == 0:
            res += 'arrêté -> ' + self.__plateau[2]._element[1].__str__()
        elif self.etat == 1:
            res += 'ralenti'
        else :
            res += 'roule à toute allure'
        res += ' , ' + self.__plateau[-1].__str__() + ' ) \n'
            
        return res       
            
            
            
        

################## Manipulation de la main ####################################

      
    def recevoirDeck(self,deck):
        """
        --> Permet de contrôler l'accès de la classe Partie à la main des joueurs 
            en l'initialisant en début de partie        
        Entrée :  * deck : array(Carte) , length = 6    
        Sortie :  * sucess : boolean               
        """
        if self.__main._element != []:
            print('Le joueur à déjà reçu un deck')
            return 0
        else:
            for card in range(6):
                sucess = self.__main.ajouterCarte(deck[card])
                if not sucess :
                    print("Echec de distribution du deck")
                
            return 1
    
    def piocher(self,card):
        """
        --> Permet de contrôler l'accès de la classe Partie à la main des joueurs 
            en piochant une carte contenue dans la main du joueur        
        Entrée :  * card : Carte    
        Sortie :  * sucess : boolean               
        """
        if len(self.__main._element) == 6:
            print('Vous possedez déjà 6 cartes dans votre main : impossible de piocher')
            return 0
            
        print('\nCarte piochée => ',card,'\n')
        self.__main.ajouterCarte(card)
        return 1
    
    
    def defausser(self,index):  
        """
        --> Permet de contrôler l'accès de la classe Partie à la des joueurs
            en retirant une carte de la main du joueur 
        Entrée :  * index : int    
        Sorties :  * card : Carte
                   * sucess : boolean               
        """
        if len(self.__main._element) == 0:
            print('Votre main est vide, vous ne pouvez plus défausser de carte')
            return [0, None]
        
        card = self.__main._element[index]
        sucess = self.__main.retirerCarte(card)
        return [sucess, card]
    

    def getCarteMain(self,index):
        """
        --> Sélection de la carte pour affichage        
        Entrées :  * index : int        
        Sorties :  * card : Carte           
        """
        
        if index not in range(6):
            print('Indice de carte inexistant')
            return None
        
        else:
            return self.__main._element[index]
        
        
################ Vérification de la validité de la carte  ##################################

     
    def carteJouable(self,card,targetPl=None):
        
        """
        --> Vérifie si la carte est posable (si il est possible d'apreès les règles de poser cette carte)
            Renvoie 1 si oui, 0 sinon
            
        Entrées :  * card : Card
                   * targetPl : Joueur
        
        Sorties :  * sucess : boolean           
        
        """
        
        # Le joueur est à l'arrêt, ralenti ou en train de rouler
        if self.etat in [0,1,2]:            
            if card.typeCarte == 'attaque' and self.etat == 2: # Le joueur attaque
                
                bottePrio = targetPl.__plateau[3]._element[0]
                botteEssence = targetPl.__plateau[3]._element[1]
                botteIncrev = targetPl.__plateau[3]._element[2]
                botteDrive = targetPl.__plateau[3]._element[3]
                
                
                if targetPl.etat == -1:
                    if card.typeAttaque == 'debLimit': # Il est possible de poser un limite de vitesse à un adversaire arrêté
                        return 1
                    else :
                        return 0
                elif targetPl.etat in [1,2]:
                    
                    if card.typeAttaque == 'feuRouge' and not bottePrio : 
                        return 1
                    elif card.typeAttaque == 'debLimit' and not bottePrio:
                        return 1
                    elif card.typeAttaque == 'panne' and not botteEssence:                                           
                        return 1
                    elif card.typeAttaque == 'crevaison' and not botteIncrev:
                        return 1
                    elif card.typeAttaque == 'accident' and not botteDrive:
                        return 1
                    else:
                        print("Impossible d'attaquer")
                        return 0     
                else :
                    print("Impossible d'attaquer")
                    return 0   
                        
            elif card.typeCarte in ['borne','botte','parade']: 
                
                # Récupération des différentes bottes posées par le joueur cible
                bottePrio = self.__plateau[3]._element[0]
                botteEssence = self.__plateau[3]._element[1]
                botteIncrev = self.__plateau[3]._element[2]
                botteDrive = self.__plateau[3]._element[3]
                
                topBataille = self.__plateau[2]._element[1]                    
                topVitesse = self.__plateau[1]._element 
                
                # Le joueur progresse 
                if card.typeCarte == 'borne' :                    
                    if self.__etat == 2 or (self.__etat == 1 and card.valeur == 25):
                        if self.score + card.valeur > 1000:                                              
                            print('Impossible de dépasser 1000 bornes')                                              
                            return 0
                        else :                                              
                            return 1
                    else : 
                        return 0   
                elif card.typeCarte == 'botte':
                    if self.etat in [0,1,2]:
                        if card.typeBotte == 'prio' and (topBataille.typeCarte == 'attaque' and topBataille.typeAttaque == 'feuRouge'):
                            self.__plateau[2].ajouterCarte(Parade('feuVert'))
                            
                        elif card.typeBotte == 'prio' and (topBataille.typeCarte == 0 and topBataille.typeAttaque == 'debLimit'):
                            self.__plateau[1].ajouterCarte(Parade('finLimit'))
                            self.__plateau[2].ajouterCarte(Parade('feuVert'))
                            
                        elif card.typeBotte == 'essence' and (topBataille.typeCarte == 'attaque' and topBataille.typeAttaque == 'panne'):
                            self.__plateau[2].ajouterCarte(Parade('gas'))
                            self.__plateau[2].ajouterCarte(Parade('feuVert'))
                            
                        elif card.typeBotte == 'increvable' and (topBataille.typeCarte == 'attaque' and topBataille.typeAttaque == 'crevaison'):
                            self.__plateau[2].ajouterCarte(Parade('roue'))
                            self.__plateau[2].ajouterCarte(Parade('feuVert'))
                            
                        elif card.typeBotte == 'drive' and (topBataille.typeCarte == 'attaque' and topBataille.typeAttaque == 'accident'):
                            self.__plateau[2].ajouterCarte(Parade('repair'))
                            self.__plateau[2].ajouterCarte(Parade('feuVert'))                               
                            
                        return 1
                            
                    else:
                        return 0
                    
                # Le joueur se défend
                else :
  
                    if card.typeParade == 'feuVert' and not bottePrio:
                        if self.etat == 0:
                            if topBataille.typeCarte == 'attaque' and  topBataille.typeAttaque == 'feuRouge':
                                return 1
                            elif topBataille.typeCarte == 'parade':
                                return 1
                            else:
                                return 0
                        else :
                            return 0    
                    #if topBataille.typeCarte == 'Attaque':
                              
                                      
                    elif card.typeParade == 'finLimit' and topVitesse == 0 and not botteDrive :
                        return 1
                    elif card.typeParade == 'gas' and self.etat == 0 and (not botteEssence or topBataille.typeAttaque == 'panne') :
                        return 1
                    elif card.typeParade == 'roue' and self.etat == 0 and (not botteIncrev or topBataille.typeAttaque == 'crevaison'):
                        return 1
                    elif card.typeParade == 'repair' and self.etat == 0 and topBataille.typeAttaque == 'accident' :
                        return 1
    
                    else :                          
                        return 0
                    #else:
                    #    return 0    
                    
        # Le joueur n'a pas démarré               
        else :
            if card.typeCarte == 'parade' and card.typeParade == 'feuVert':               
                return 1
            else:
                return 0 
        
                
    
############### Manipulation du plateau #######################################        
    
    def poserCartePlateau(self,card,targetPl=None):
        
        """
        --> Si la carte est viable (càd posable), la pose et modifie l'état du joueur (en attaque ou en défense) 
            puis distribue les points associés puis renvoie 1 si la carte a été posée, 0 sinon
            
        Entrées :  * card : Carte
                   * targetPl : Joueur
        
        Sorties :  * sucess : boolean           
        
        """
        
        # La carte peut être posée
        if self.carteJouable(card,targetPl):
            if card.typeCarte == 'attaque':  
                if card.typeAttaque == 'debLimit':
                    resPose = targetPl.__plateau[1].ajouterCarte(card)
                    if targetPl.etat == 2:                                                                                            
                        targetPl.etat = resPose                
                    return 1
                else :
                    resPose = targetPl.__plateau[2].ajouterCarte(card)
                    targetPl.etat = resPose                                    
                    return 1
                           
            elif card.typeCarte == 'borne':
                if card.valeur in [25,50,75,100,200]:               
                    resPose = self.__plateau[0].ajouterCarte(card)  
                    self.score += card.valeur   
                    return resPose 
                else :
                    print('Type de carte borne invalide')
                    return 0               
            elif card.typeCarte == 'parade':
                if card.typeParade in ['feuVert','gas','roue','repair']:                      
                    resPose = self.__plateau[2].ajouterCarte(card)
                    if self.etat == -1 and card.typeParade == 'feuVert' and self.__plateau[1]._element == 0:
                        self.etat = 1
                    else :                                                                                                         
                        self.etat = resPose
                    return 1
                elif card.typeParade == 'finLimit':
                    resPose = self.__plateau[1].ajouterCarte(card)
                    if self.etat == -1 and self.__plateau[1]._element == 0:                        
                        self.etat = 1
                    else :                                           
                        self.etat = resPose
                    return 1
                else :
                    print('Type de carte parade invalide')
                    return 0
                  
            elif card.typeCarte == 'botte':            
                if card.typeBotte in ['prio','essence','increvable','drive']:                                     
                        
                    resPose = self.__plateau[3].ajouterCarte(card)                    
                    self.score += 100
                    self.etat = 2
                    return 1
                else :
                    print('Type de carte botte invalide')
                    return 0
            else:
                return 0   
        # Impossible de poser la carte    
        else :            
            print('Impossible de jouer cette carte')
            return 0             
