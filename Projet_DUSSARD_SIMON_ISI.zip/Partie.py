# -*- coding: utf-8 -*-
"""
Created on Thu Dec 24 01:23:51 2020

@author: Louis
"""
from Carte import Carte, Borne, Attaque, Parade, Botte
from Pile import pPioche, pDefausse
import random

class Partie():

    def __init__(self,player,s,ID='0'):

        self.joueur = player
        self.idPartie = ID # Dans le cas où le jeu permet de sauvegarder une partie
        self.pioche = pPioche([])
        self.defausse = pDefausse([],self.pioche)
        self.score = [0]*len(self.joueur)
        self.sound = s



##################### Gestion du deck de cartes ###############################

    def creerDeck(self):

        deck = []

        #Creation carte de type borne
        for k in range(10):
            deck.append(Borne(25))
            deck.append(Borne(50))
            deck.append(Borne(75))
        for k in range(12):
            deck.append(Borne(100))
        for k in range(4):
            deck.append(Borne(200))


        #Creation carte de type parade
        for k in range(14):
            deck.append(Parade('feuVert'))
        for k in range(6):
            deck.append(Parade('finLimit'))
            deck.append(Parade('gas'))
            deck.append(Parade('roue'))
            deck.append(Parade('repair'))

        #Creation carte de type attaque
        for k in range(5):
            deck.append(Attaque('feuRouge'))
        for k in range(4):
            deck.append(Attaque('debLimit'))
        for k in range(3):
            deck.append(Attaque('panne'))
            deck.append(Attaque('crevaison'))
            deck.append(Attaque('accident'))

        #Creation carte de type borne
        deck.append(Botte('prio'))
        deck.append(Botte('essence'))
        deck.append(Botte('increvable'))
        deck.append(Botte('drive'))

        return deck

    def melangerDeck(self):
        deck = self.creerDeck()
        shuffledDeck = []
        for carte in range(len(deck)):
            temp = random.choice(deck)
            shuffledDeck.append(temp)
            deck.remove(temp)
        return shuffledDeck

    def distribDeck(self):

        deck = self.melangerDeck()
        deckJoueur = [[]]*len(self.joueur)


        for k in range(6):
            for cpt in range(len(self.joueur)):
                if k == 0:
                    deckJoueur[cpt] = [deck[0]]
                    deck.remove(deck[0])
                else:
                    deckJoueur[cpt].append(deck[0])
                    deck.remove(deck[0])

        self.pioche.ajouterCarte(deck)

        return deckJoueur


######### Outils pour la partie ###############################################

    def demarrerPartie(self):
        d = self.distribDeck()
        for k in range(len(self.joueur)):
            self.joueur[k].recevoirDeck(d[k])
                              
                        

    def finPartie(self):
        if self.pioche._element == [] and self.defausse._element == []:
            return 1
        for p in self.joueur:
            if p.score == 1000:
                print(p.nom,'a gagné la partie')
                return 1
        return 0


    def choix(self,p):
        choice = -1

        while choice not in [1,2,3] :

            print("\n Actions possibles \n 1. Jouer \n 2. Defausser une carte \n 3. Passer son tour ")
            choice = input('Que voulez-vous faire ' + p.nom + ' ? (Répondez 1,2 ou 3) ')   
            if not choice.isdigit():
                print('Saisie invalide, veuillez réessayer')
                choice = - 1
                continue
            elif int(choice) not in [1,2,3]:
                print('Saisie invalide, veuillez réessayer')
                choice = - 1
                continue
            else :
                choice = int(choice)
                return choice


################### Fonction principale de jeu ################################

    def jouer(self,index):
        
        if self.pioche._element == []:
            deck = self.defausse._element
            self.pioche.ajouterCarte(deck)
            self.defausse._element = []
        
        player = self.joueur[index]        
        print('-----------------------------------------------------')
        print('** Au tour de',player.nom,'de jouer ** \n')
        player.printMain()
        player.printPlateau()
        
        choice = self.choix(player)
        correctChoice = 0
        
        while not correctChoice : 
            
            if choice == 3:
                return 1
    
            elif choice == 2:
    
                ind = input('Quelle carte voulez-vous défausser (indice de 1 à 6)')
                resDefauss = player.defausser(int(ind)-1)
                if resDefauss[0]:                
                    rmPioche = self.pioche.retirerCarte()
                    self.defausse.ajouterCarte(resDefauss[1])
                    player.piocher(rmPioche)
                    return 1
                else :
                    return 0
        
    
            elif choice == 1:
                
                     
                while True:             
                    index = input('Quelle carte voulez vous jouer ? ')
                    if index in ['1','2','3','4','5','6']:                                
                        break
                    else :
                        print('Saisie incorrecte (carte de 1 à 6)')
                
                selectCard = player.getCarteMain(int(index)-1)  
                
                if selectCard.typeCarte == 'attaque' and player.etat in [0,2]:
                    otherPl = self.joueur.copy()
                    otherPl.remove(player)                    
                    while True :
                        print('Quel joueur voulez-vous attaquer ? (Saisssez un numéro)')
                        for k in range(len(otherPl)):
                            print('\t',k+1,'.',otherPl[k].nom)
                        targetPl = int(input())
                        if targetPl in range(1,len(otherPl)+1):
                            targetPl -= 1
                            break
                        else :
                            print('Saisie incorrecte')
                            
                    if player.poserCartePlateau(selectCard,otherPl[targetPl]):
                        selectCard = player.defausser(int(index)-1)                          
                        rmPioche = self.pioche.retirerCarte()
                        self.defausse.ajouterCarte(selectCard[1])                                             
                        player.piocher(rmPioche)                                                  
                        return 1
                    else:
                        print("échec de l'attaque")
                        choice = self.choix(player)
                        continue
                    
                else :
                    if player.poserCartePlateau(selectCard):
                        selectCard = player.defausser(int(index)-1) 
                        rmPioche = self.pioche.retirerCarte()
                        self.defausse.ajouterCarte(selectCard[1])                                             
                        player.piocher(rmPioche)
                        if selectCard[1].typeCarte == 'botte':
                            print('Vous pouvez rejouer après avoir posé une carte botte !')
                            player.printMain()
                            choice = self.choix(player)                                              
                            continue
                        else :                                                               
                            return 1
                    else :
                        choice = self.choix(player)
                        continue
                    
                    
    def jouerGUI(self,player,choice,iCarte=None,targetPl=None):
        
        if self.pioche._element == []:
            deck = self.defausse._element
            self.pioche.ajouterCarte(deck)
            self.defausse._element = []
        
        if choice == 3 :
            return [1]
        
        elif choice == 2 :
            resDefauss = player.defausser(int(iCarte)-1)
            if resDefauss[0]:
                rmPioche = self.pioche.retirerCarte()
                self.defausse.ajouterCarte(resDefauss[1])
                player.piocher(rmPioche)
                return [1]
            else :
                return [0,'échec de la défausse']
            
        else :  
            
            selectCard = player.getCarteMain(int(iCarte)-1) 
              
            if selectCard.typeCarte == 'attaque' and player.etat in [0,2]:
                if player.poserCartePlateau(selectCard,targetPl):
                        
                    selectCard = player.defausser(int(iCarte)-1)                          
                    rmPioche = self.pioche.retirerCarte()
                    self.defausse.ajouterCarte(selectCard[1])                                             
                    player.piocher(rmPioche)                                                  
                    return [1]
                else:
                    return [0,"Impossible de l'attaque"]
            else :
                if player.poserCartePlateau(selectCard):                       
                    selectCard = player.defausser(int(iCarte)-1) 
                    rmPioche = self.pioche.retirerCarte()
                    self.defausse.ajouterCarte(selectCard[1])                                             
                    player.piocher(rmPioche)
                    if selectCard[1].typeCarte == 'botte':                                        
                        return [2,"Vous pouvez rejouer après avoir posé une carte botte !"]                       
                    else :                                                               
                        return [1]                 
                else :
                    return [0,'Impossible de poser cette carte sur votre plateau']    
                
                    
                
    