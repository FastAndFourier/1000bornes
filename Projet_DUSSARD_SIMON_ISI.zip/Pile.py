# -*- coding: utf-8 -*-
"""
Auteurs : Bastien DUSSARD , Louis SIMON

Classe mère et classes filles géréant les piles dans le jeu.
Une pile est par essence un de cartes. On propose ici de construire plusieurs classes filles basée
sur un classe abstraite. Les cartes filles permettent de définir localement :
    * Les conditions d'ajout de cartes
    * L'affichage de la pile (une partie des fonctions __str__() ont été utilisés uniquement pour le déboguage)
    
Il existe sept types de piles (développées ici sous forme de classes filles):
    * Pioche
    * Defausse
    * Main
    * Vitesse
    * Bataille
    * Botte
    * Borne
    
"""

from abc import ABC, abstractmethod
from Carte import Carte

class Pile(ABC):
    
    def __init__(self,tab):
        self._element = tab
        
    @abstractmethod    
    def __str__(self):
        pass

    @abstractmethod
    def ajouterCarte(self,card):
        pass

###############################################################################    

class pMain(Pile):
    
    def __init__(self,tab):
        if len(tab) > 6:
            print('Une main ne peut être constituée que de 6 cartes')
        else :
            super().__init__(tab)
    

    def ajouterCarte(self,card):
        if len(self._element) > 6:
            return 0
        else :                  
            self._element.append(card)
            return 1      
    
    def retirerCarte(self,card):
        if isinstance(card,Carte):
            self._element.remove(card)
            return 1
        return 0
    
    def __str__(self):
        res = ''
        for cpt,card in enumerate(self._element):
            res += str(cpt+1) + '. ' + card.__str__() + '\n'         
        return res


###############################################################################

        
class pPioche(Pile):
    
    def __init__(self,tab):
        if len(tab) <= 106:                  
            super().__init__(tab)            
        else:
            print("Erreur de taille à l'ini")
           
    def ajouterCarte(self,card):
        if len(self._element) > 106:
            return 0
        else :
            if isinstance(card,list):
                for c in card:
                    self._element.append(c)                  
            else:
                self._element.append(card)
            return 1       

    def retirerCarte(self):
        if self._element != []:
            res = self._element[0]
            self._element.remove(res)
            return res
        else:
            print('La pioche est vide !')
            return -1

    
    def __str__(self,tab):
        
        if self._element == []:
            return 'Pioche : vide'
        

###############################################################################

class pDefausse(Pile):
    
    def __init__(self,tab,pPioche):
        super().__init__(tab)
        self.pioche = pPioche
        
        
    def ajouterCarte(self,card):
        if len(self._element) > 106:
            return 0
        else :
            if isinstance(card,list):
                for c in card:
                    self._element.append(c)                  
            else:
                self._element.append(card)
            return 1
        
    def __str__(self):
        if self.pioche == []:
            return "La défausse est pleine" 

###############################################################################
        
class pVitesse(Pile):
        
          
    """         
        self._element = 2 si la dernière carte est une fin de limite (le joueur roule à allure normale)
        self._element = 1 si la dernière carte est un début de limite (le joueur est ralenti)
        self._element = None si échec
    """        
    
    
    def __init__(self,tab=-1):
        super().__init__(tab)
        
        
    def ajouterCarte(self,card):

        
        if card.typeCarte == 'attaque' and card.typeAttaque == 'debLimit':
            self._element = 0
            return 1
        elif card.typeCarte == 'parade' and card.typeParade == 'finLimit':
            self._element = 1
            return 2
        else :
            print('Type de carte incorrect pour la pile bataille')
            return None
 
        
    def __str__(self):
        res = "Vitesse : "
        if self._element == -1:
            return res + "vide "
        elif self._element == 0:
            return res + "ralenti"
        else :
            return res + "roule à toute allure"

###############################################################################

class pBataille(Pile):
    
    """
        self._element[0] = 0 si le joueur est attaqué et donc stoppé
        self._element[0] = 2 si le joueur redémarre après avoir poser la bonne carte parade et un feu vert
        self._element[0] = None si échec
        
        self._element[1] contient la carte "active" de la pile bataille (en haut de la pile)                  
        --> Nécessité de récupérer cette carte pour l'affichage         
    """
    
    def __init__(self,tab=[-1,None]):             
        super().__init__(tab)
        
    def ajouterCarte(self,card):
        
        if card.typeCarte == 'attaque' and card.typeAttaque in ['feuRouge','panne','crevaison','accident']:
            self._element = [0,card]
            return 0
        elif card.typeCarte == 'parade' and card.typeParade in ['feuVert','gas','roue','repair']:
            if self._element[0] in [-1,0] and card.typeParade == 'feuVert':
                self._element = [2,card]
                return 2
            else :
                self._element = [0,card]
                return 0
        else :
            print('Type de carte incorrect pour la pile bataille')
            return None    
               
        
    def __str__(self):
       
        if self._element[0] == -1:
            return "Bataille : vide"        
        else :
            return "Bataille : " + self._element[1].__str__()

###############################################################################

class pBotte(Pile):
    """
        Contient un tableau de booléens stipulant la précense ou l'absence de cartes bottes
            * 1er élément : véhicule prioritaire
            * 2eme élément : citerne d'essence
            * 3eme élément : increvable
            * 4eme élément : as du volant
    """
    
    
    
    def __init__(self,tab=[0,0,0,0]):
        super().__init__(tab)
        
        
    def ajouterCarte(self,card):
        if card.typeCarte != 'botte' or card.typeBotte not in ['prio','essence','increvable','drive']:
            print('Type de carte incorrect pour la pile Botte')
            return 0
        else :
            if card.typeBotte == 'prio':
                self._element[0] = 1
                return 1
            elif card.typeBotte == 'essence':
                self._element[1] = 1
                return 1
            elif card.typeBotte == 'increvable':
                self._element[2] = 1
                return 1
            else :
                self._element[3] = 1
                return 1
            
        
    def __str__(self):
        res = ''
        if self._element == [0]*4:
            return res
        else :                   
            for cpt,card in enumerate(self._element):  
                if card != 0 and cpt == 0 :
                    res += 'véhicule prioritaire '
                elif card != 0 and cpt == 1:
                    res += "citerne d'essence "
                elif card != 0 and cpt == 2:
                    res += "increvable , "
                elif card != 0 and cpt == 3:
                    res += "as du volant "
                else:
                    res += ""
                
            
            return res
               
                        
                

###############################################################################

class pBorne(Pile):
    
    def __init__(self,tab=[0,0,0,0,0]):
        super().__init__(tab)
    
        
    def ajouterCarte(self,card):
        
        if card.typeCarte != 'borne' or card.valeur not in [25,50,75,100,200] :
            print('Type de carte incorrect pour la pile Borne')
            return 0
        
        else :
            
            if card.valeur == 25:
                self._element[0] += 1
                return 1                  
            elif card.valeur == 50:
                self._element[1] += 1
                return 1                
            elif card.valeur == 75:
                self._element[2] += 1
                return 1            
            elif card.valeur == 100:
                self._element[3] += 1
                return 1            
            else :
                if self._element[4] < 2:                                
                    self._element[4] += 1
                    return 1
                else :
                    print('Impossible de poser plus de deux cartes bornes 200km')
                    return 0  
        
        
        
        
    def __str__(self):
        
        if self._element == [0,0,0,0,0]:
            return 'Pile borne : vide '
        else :
            return 'Pile borne : ' + str(self._element[0]*25 + self._element[1]*50 +
                                 self._element[2]*75 + self._element[3]*100 + self._element[4]*200)
        
    