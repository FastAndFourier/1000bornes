# -*- coding: utf-8 -*-
"""
Ce fichier python permet de jouer au mille bornes dans l'invite de commande

Il est recommandé de jouer dans une invite de commande détachéé de toute IDE.
La musique ne s'arrêtant automatiquement qu'à la fin du programme, une interruption
du programme avant la fin n'arrête pas la musique.
----> il est donc nécessaire de fermer l'invite de commande !!

"""

from Partie import Partie
from Joueur import Joueur
import winsound


nbJoueur = -1
while nbJoueur not in [2,3,4]:
    nbJoueur = input('Nouvelle partie de 1000 bornes. \nCombien de joueurs ? : ')
    
    if not nbJoueur.isdigit():
        print('Nombre de joueurs incorrect (2 à 4 joueurs requis)')
        nbJoueur = -1
        continue     
    elif int(nbJoueur) not in [2,3,4]:
        print('Nombre de joueurs incorrect (2 à 4 joueurs requis)')
        nbJoueur = -1
        continue
    else :
        nbJoueur = int(nbJoueur)
        break
        

sound = ''

while sound not in ['y','n']:
    s = input('Voulez-vous activer le son ? (y/n) ')
    if s == 'y':
        s = 1
        break
    elif s == 'n':
        s = 0
        break
    else:
        print('Saisie inconnue (y/n)')
        continue
    
player = []
for k in range(int(nbJoueur)):
    nom = input('Nom du joueur ' + str(k+1) + ': ')
    player.append(Joueur(nom,s))

scoreTot = [0]*nbJoueur

    
   
p = Partie(player,s)   
p.demarrerPartie()    

if p.sound :
	# Musique : Running in the 90's
	# Vous pouvez rajouter votre propre musique sous format .wav
    winsound.PlaySound("background.wav", winsound.SND_ALIAS|winsound.SND_ASYNC)  

limitRound = 0

while not(p.finPartie()):
       
    for iPlayer in range(nbJoueur):                    
        p.jouer(iPlayer)
    
    if not((limitRound+1)%10):
        continuer = input('Vous jouez depuis maintenant' + str(limitRound+1) +'tours : Voulez vous continuer à jouer ? (y/n)')
        if continuer != 'y':
            break
    limitRound += 1    

if p.sound:   
    print("Tapez 'y' si vous voulez arrêter la partie (et donc la musique). Sinon ne faites rien et profitez de ce pur son")
    x = input()
    winsound.PlaySound(None, winsound.SND_PURGE)
    